const withPlugins = require("next-compose-plugins");
const withSass = require("@zeit/next-sass");
const withImages = require("next-images");
const withSourceMaps = require("@zeit/next-source-maps");

const withMDX = require("@next/mdx")({
  extension: /\.mdx?$/,
});

const nextConfig = {
  pageExtensions: ["mdx", "js", "jsx", "md"],
  // useFileSystemPublicRoutes: false,
  target: "server",
  webpack: (config, { isServer }) => {
    if (!isServer) {
      config.node = {
        fs: "empty",
      };
    }
    return config;
  },
  env: {
    SESSION_KEY: "six7",
    SESSION_SECRET: "dfjdsfF$5SGDFB__FEW§ASD*_;>ds<>|fafsfee34343",
    REDIS_URL_PRODUCTION: "",
    SERVER_URL: "http://localhost:8080",
    DB_USERNAME: "ryzen",
    DB_PASSWORD: "2400g",
    DB_TABLE: "nextjs-apollo-theme-ui",
    DATABASE_URL: "",
    lastfmUser: "gung",
    lastfmApiKey: "216ba84a21b975f2873c68cee721a0b1",
    lastfmCount: 10,
    gitUser: "screamwork",
    socialTwitter: "https://twitter.com/gu_ng",
    socialYoutube: "https://www.youtube.com/channel/UC9elwy5eDAqjavqxUS_RgqQ",
    socialFacebook: "https://www.facebook.com/abugung/",
    socialInstagram: "https://www.instagram.com/_.gung._/",
    socialBitbucket:
      "https://bitbucket.org/%7Bd8f96549-546a-42c4-afd1-9b66266d25f8%7D/",
    socialGithub: "https://github.com/screamwork",
    lastfmUrl: "http://last.fm/user/gung",
    spotifyUrl:
      "https://open.spotify.com/user/1128845569?si=lpkYYRllTVCOrLiT56aOhQ",
    flickrKey: "2c0c89aa7d3dc188c8b833d3b3a39b46",
    flickrSecret: "0edca7ad74a23532",
  },
};

module.exports = withPlugins(
  [withMDX, withSass, withImages, withSourceMaps],
  nextConfig
);
