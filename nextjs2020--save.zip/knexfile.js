module.exports = {
  development: {
    client: "postgresql",
    connection: {
      database: "nextjs-apollo-theme-ui",
      user: "ryzen",
      password: "2400g",
    },
    pool: {
      min: 2,
      max: 10,
    },
    migrations: {
      tableName: "knex_migrations",
      directory: __dirname + "/db/migrations/development",
    },
    seeds: {
      directory: __dirname + "/db/seeds/development",
    },
  },

  production: {
    client: "postgresql",
    connection: {
      database: "my_db",
      user: "username",
      password: "password",
    },
    pool: {
      min: 2,
      max: 10,
    },
    migrations: {
      tableName: "knex_migrations",
      directory: __dirname + "/db/migrations/production",
    },
    seeds: {
      directory: __dirname + "/db/seeds/production",
    },
  },
};
